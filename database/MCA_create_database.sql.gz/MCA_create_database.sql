-- MCA (Microbial Clinical Atlas) – MySQL schema
-- Engine: InnoDB
-- Charset: utf8 / utf8_general_ci

CREATE DATABASE MCA;
USE MCA;

-- =========================================================
-- 1) Core passport table
-- =========================================================
CREATE TABLE mca_taxon_passport (
  passport_id        VARCHAR(32)  NOT NULL,       -- MCA-BAC-000001
  preferred_name     VARCHAR(255) NOT NULL,       -- Enterobacteriaceae
  taxon_rank         ENUM('family','genus','species','strain','clade') NOT NULL, -- (avoid RANK)
  lineage            TEXT         NOT NULL,       -- pipe-separated taxonomy
  ncbi_taxid         VARCHAR(32)  NULL,           -- keep as string

  is_pathobiont      ENUM('yes','no','context dependent','unknown') NOT NULL DEFAULT 'unknown',
  last_reviewed      DATE         NOT NULL,
  version            VARCHAR(16)  NOT NULL DEFAULT 'v0.1',

  created_at         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (passport_id),
  INDEX idx_preferred_name (preferred_name),
  INDEX idx_taxon_rank (taxon_rank),
  INDEX idx_ncbi_taxid (ncbi_taxid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- =========================================================
-- 2) Synonyms (0..n per passport)
-- =========================================================
CREATE TABLE mca_taxon_synonym (
  synonym_id   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id  VARCHAR(32)     NOT NULL,
  synonym      VARCHAR(255)    NOT NULL,

  PRIMARY KEY (synonym_id),
  UNIQUE INDEX uq_passport_synonym (passport_id, synonym),
  CONSTRAINT fk_synonym_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- =========================================================
-- 3) Biology (0..1 per passport)
-- =========================================================
CREATE TABLE mca_taxon_biology (
  passport_id       VARCHAR(32) NOT NULL,
  gram_status       ENUM('positive','negative','variable','na','unknown') NOT NULL DEFAULT 'unknown',
  morphology        VARCHAR(255) NULL,
  oxygen_tolerance  VARCHAR(255) NULL,

  PRIMARY KEY (passport_id),
  CONSTRAINT fk_biology_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE mca_taxon_key_trait (
  trait_id     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id  VARCHAR(32)     NOT NULL,
  trait_text   VARCHAR(255)    NOT NULL,  -- (avoid KEY)

  PRIMARY KEY (trait_id),
  UNIQUE INDEX uq_passport_trait (passport_id, trait_text),
  CONSTRAINT fk_trait_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- =========================================================
-- 4) Ecology lists
-- =========================================================
CREATE TABLE mca_taxon_primary_niche (
  niche_id     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id  VARCHAR(32)     NOT NULL,
  niche_text   VARCHAR(255)    NOT NULL,

  PRIMARY KEY (niche_id),
  UNIQUE INDEX uq_passport_niche (passport_id, niche_text),
  CONSTRAINT fk_niche_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE mca_taxon_reservoir (
  reservoir_id     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id      VARCHAR(32)     NOT NULL,
  reservoir_source VARCHAR(255)    NOT NULL,  -- SOURCE is not reserved per your table

  PRIMARY KEY (reservoir_id),
  UNIQUE INDEX uq_passport_reservoir (passport_id, reservoir_source),
  CONSTRAINT fk_reservoir_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE mca_taxon_transmission_route (
  route_id     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id  VARCHAR(32)     NOT NULL,
  route_text   VARCHAR(255)    NOT NULL,

  PRIMARY KEY (route_id),
  UNIQUE INDEX uq_passport_route (passport_id, route_text),
  CONSTRAINT fk_route_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- =========================================================
-- 5) Clinical summary lists
-- =========================================================
CREATE TABLE mca_taxon_role (
  role_id      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id  VARCHAR(32)     NOT NULL,
  role_text    VARCHAR(255)    NOT NULL,  -- ROLE is not reserved per your table

  PRIMARY KEY (role_id),
  UNIQUE INDEX uq_passport_role (passport_id, role_text),
  CONSTRAINT fk_role_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE mca_taxon_typical_specimen (
  specimen_id  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id  VARCHAR(32)     NOT NULL,
  specimen_text VARCHAR(255)   NOT NULL,

  PRIMARY KEY (specimen_id),
  UNIQUE INDEX uq_passport_specimen (passport_id, specimen_text),
  CONSTRAINT fk_specimen_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE mca_taxon_risk_context (
  context_id   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id  VARCHAR(32)     NOT NULL,
  context_text VARCHAR(255)    NOT NULL,  -- CONTEXT not reserved per your table

  PRIMARY KEY (context_id),
  UNIQUE INDEX uq_passport_context (passport_id, context_text),
  CONSTRAINT fk_context_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE mca_taxon_bloom_trigger (
  trigger_id    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id   VARCHAR(32)     NOT NULL,
  trigger_text  VARCHAR(255)    NOT NULL,  -- (avoid TRIGGER)

  PRIMARY KEY (trigger_id),
  UNIQUE INDEX uq_passport_trigger (passport_id, trigger_text),
  CONSTRAINT fk_trigger_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE mca_taxon_amr_highlight (
  amr_id       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id  VARCHAR(32)     NOT NULL,
  highlight_text VARCHAR(255)  NOT NULL,

  PRIMARY KEY (amr_id),
  UNIQUE INDEX uq_passport_amr (passport_id, highlight_text),
  CONSTRAINT fk_amr_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- =========================================================
-- 6) Taxon-level evidence (PMIDs only)
-- =========================================================
CREATE TABLE mca_taxon_evidence_pmid (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id VARCHAR(32)     NOT NULL,
  pmid        VARCHAR(32)     NOT NULL,

  PRIMARY KEY (id),
  UNIQUE INDEX uq_passport_pmid (passport_id, pmid),
  INDEX idx_pmid (pmid),
  CONSTRAINT fk_taxon_pmid_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- =========================================================
-- 7) Clinical associations (per-claim evidence)
-- =========================================================
CREATE TABLE mca_clinical_association (
  association_id   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  passport_id      VARCHAR(32)     NOT NULL,
  association_text TEXT            NOT NULL,
  evidence_level   ENUM('E1','E2','E3') NOT NULL,
  evidence_type    VARCHAR(255)    NOT NULL,
  created_at       TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (association_id),
  INDEX idx_assoc_passport (passport_id),
  INDEX idx_assoc_evidence_level (evidence_level),
  CONSTRAINT fk_assoc_passport
    FOREIGN KEY (passport_id) REFERENCES mca_taxon_passport(passport_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE mca_clinical_association_pmid (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  association_id BIGINT UNSIGNED NOT NULL,
  pmid           VARCHAR(32)     NOT NULL,

  PRIMARY KEY (id),
  UNIQUE INDEX uq_assoc_pmid (association_id, pmid),
  INDEX idx_assoc_pmid (pmid),
  CONSTRAINT fk_assoc_pmid_assoc
    FOREIGN KEY (association_id) REFERENCES mca_clinical_association(association_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

